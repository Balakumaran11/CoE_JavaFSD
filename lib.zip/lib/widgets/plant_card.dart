import 'package:flutter/material.dart';
import 'package:plantpal/models/plant.dart';

class PlantCard extends StatelessWidget {
  final Plant plant;
  final VoidCallback? onWaterPressed;
  final VoidCallback onDeletePressed;
  final VoidCallback onHealthPressed;
  final bool isWatering;

  const PlantCard({
    super.key,
    required this.plant,
    this.onWaterPressed,
    required this.onDeletePressed,
    required this.onHealthPressed,
    this.isWatering = false,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [
            Colors.green[50]!,
            Colors.green[100]!,
          ],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(20),
        boxShadow: [
          BoxShadow(
            color: Colors.grey.withOpacity(0.3),
            blurRadius: 10,
            offset: const Offset(0, 5),
          ),
        ],
      ),
      child: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  plant.name,
                  style: TextStyle(
                    fontSize: 20,
                    fontWeight: FontWeight.bold,
                    color: Colors.green[900],
                  ),
                ),
                IconButton(
                  icon: Icon(Icons.delete, color: Colors.red[400]),
                  onPressed: onDeletePressed,
                ),
              ],
            ),
            const SizedBox(height: 8),
            // Health Status
            InkWell(
              onTap: onHealthPressed,
              child: Container(
                padding: const EdgeInsets.symmetric(vertical: 8, horizontal: 12),
                decoration: BoxDecoration(
                  color: _getHealthColor().withOpacity(0.2),
                  borderRadius: BorderRadius.circular(20),
                ),
                child: Row(
                  children: [
                    Icon(Icons.eco, color: _getHealthColor()),
                    const SizedBox(width: 8),
                    Text(
                      'Health: ${plant.healthStatus}',
                      style: TextStyle(
                        color: _getHealthColor(),
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    const Spacer(),
                    Icon(Icons.edit, color: _getHealthColor(), size: 18),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 16),
            // Watering Progress
            ClipRRect(
              borderRadius: BorderRadius.circular(10),
              child: LinearProgressIndicator(
                value: plant.daysSinceWatered / plant.wateringFrequency,
                backgroundColor: Colors.grey[200],
                color: plant.needsWatering ? Colors.orange[400] : Colors.green[400],
                minHeight: 15,
              ),
            ),
            const SizedBox(height: 8),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  '${plant.daysSinceWatered}/${plant.wateringFrequency} days',
                  style: TextStyle(
                    color: plant.needsWatering ? Colors.orange[800] : Colors.green[800],
                    fontWeight: FontWeight.bold,
                  ),
                ),
                Container(
                  padding: const EdgeInsets.symmetric(vertical: 4, horizontal: 12),
                  decoration: BoxDecoration(
                    color: plant.needsWatering 
                        ? Colors.orange[100]
                        : Colors.green[100],
                    borderRadius: BorderRadius.circular(20),
                  ),
                  child: Text(
                    plant.needsWatering ? 'NEEDS WATER!' : 'Hydrated',
                    style: TextStyle(
                      color: plant.needsWatering ? Colors.orange[800] : Colors.green[800],
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 16),
            SizedBox(
              width: double.infinity,
              child: ElevatedButton(
                style: ElevatedButton.styleFrom(
                  backgroundColor: isWatering ? Colors.grey : Colors.green[700],
                  padding: const EdgeInsets.symmetric(vertical: 12),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(15),
                  ),
                ),
                onPressed: isWatering ? null : onWaterPressed,
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    const Icon(Icons.water_drop, color: Colors.white),
                    const SizedBox(width: 8),
                    const Text(
                      'WATER NOW',
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 16,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    if (isWatering) ...[
                      const SizedBox(width: 8),
                      const SizedBox(
                        width: 16,
                        height: 16,
                        child: CircularProgressIndicator(
                          strokeWidth: 2,
                          color: Colors.white,
                        ),
                      ),
                    ],
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Color _getHealthColor() {
    if (plant.healthScore >= 80) return Colors.green;
    if (plant.healthScore >= 50) return Colors.orange; 
    return Colors.red;
  }
}