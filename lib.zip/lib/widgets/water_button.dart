import 'package:flutter/material.dart';

class WaterButton extends StatefulWidget {
  final int plantId;
  final int daysSinceWatering;
  final Future<void> Function() onPressed;

  const WaterButton({
    super.key,
    required this.plantId,
    required this.daysSinceWatering,
    required this.onPressed,
  });

  @override
  State<WaterButton> createState() => _WaterButtonState();
}

class _WaterButtonState extends State<WaterButton> {
  bool _isLoading = false;

  Future<void> _handlePress() async {
    if (_isLoading) return;
    
    setState(() => _isLoading = true);
    try {
      await widget.onPressed();
    } catch (e) {
      debugPrint('Watering error: $e');
      rethrow;
    } finally {
      if (mounted) {
        setState(() => _isLoading = false);
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Text('${widget.daysSinceWatering} days since watering'),
        const SizedBox(height: 8),
        ElevatedButton(
          onPressed: _isLoading ? null : _handlePress,
          style: ElevatedButton.styleFrom(
            backgroundColor: _isLoading ? Colors.grey : Colors.blue,
            padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 12),
          ),
          child: _isLoading
              ? const Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    SizedBox(
                      width: 20,
                      height: 20,
                      child: CircularProgressIndicator(
                        strokeWidth: 2,
                        color: Colors.white,
                      ),
                    ),
                    SizedBox(width: 8),
                    Text('Watering...'),
                  ],
                )
              : const Text('WATER NOW'),
        ),
      ],
    );
  }
}