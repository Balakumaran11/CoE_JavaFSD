import 'package:flutter/material.dart';

class HealthEditor extends StatefulWidget {
  final int initialScore;
  final Function(int) onSave;

  const HealthEditor({
    super.key,
    required this.initialScore,
    required this.onSave,
  });

  @override
  State<HealthEditor> createState() => _HealthEditorState();
}

class _HealthEditorState extends State<HealthEditor> {
  late int _currentScore;

  @override
  void initState() {
    super.initState();
    _currentScore = widget.initialScore;
  }

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: const Text('Update Plant Health'),
      content: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Text(
            _getStatusText(_currentScore),
            style: TextStyle(
              color: _getHealthColor(_currentScore),
              fontWeight: FontWeight.bold,
            ),
          ),
          Slider(
            value: _currentScore.toDouble(),
            min: 0,
            max: 100,
            divisions: 20,
            label: _currentScore.toString(),
            onChanged: (value) => setState(() => _currentScore = value.toInt()),
          ),
        ],
      ),
      actions: [
        TextButton(
          onPressed: () => Navigator.pop(context),
          child: const Text('Cancel'),
        ),
        TextButton(
          onPressed: () {
            widget.onSave(_currentScore);
            Navigator.pop(context);
          },
          child: const Text('Save'),
        ),
      ],
    );
  }

  String _getStatusText(int score) {
    if (score >= 80) return 'Excellent (${score}%)';
    if (score >= 50) return 'Good (${score}%)'; 
    return 'Needs Care (${score}%)';
  }

  Color _getHealthColor(int score) {
    if (score >= 80) return Colors.green;
    if (score >= 50) return Colors.orange;
    return Colors.red;
  }
}