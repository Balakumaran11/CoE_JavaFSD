import 'package:flutter/material.dart';
import 'package:plantpal/models/plant.dart';
import 'package:plantpal/services/firestore_service.dart';
import 'package:plantpal/widgets/plant_card.dart';
import 'package:plantpal/screens/add_plant_screen.dart';
import 'package:plantpal/widgets/health_editor.dart';
import 'package:plantpal/widgets/water_button.dart'; // ✅ Fixed Import

class HomeScreen extends StatefulWidget {
  final String userId;
  const HomeScreen({super.key, required this.userId});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final FirestoreService _firestoreService = FirestoreService();
  final TextEditingController _searchController = TextEditingController();
  bool _isWatering = false;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.green[50],
      appBar: AppBar(
        title: const Text(
          'My Garden',
          style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
        ),
        centerTitle: true,
        backgroundColor: Colors.teal[700],
        iconTheme: const IconThemeData(color: Colors.white),
        elevation: 5,
        shape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.vertical(bottom: Radius.circular(20)),
        ),
      ),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(16.0),
            child: Container(
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(30),
                boxShadow: [
                  BoxShadow(
                    color: Colors.green.withOpacity(0.4),
                    blurRadius: 12,
                    offset: const Offset(0, 5),
                  ),
                ],
              ),
              child: TextField(
                controller: _searchController,
                decoration: InputDecoration(
                  hintText: 'Search your plants...',
                  hintStyle: TextStyle(color: Colors.teal[600]),
                  prefixIcon: Icon(Icons.search, color: Colors.teal[800]),
                  border: InputBorder.none,
                  contentPadding: const EdgeInsets.symmetric(vertical: 15),
                ),
              ),
            ),
          ),
          Expanded(
            child: StreamBuilder<List<Plant>>(
              stream: _firestoreService.getPlantsStream(widget.userId),
              builder: (context, snapshot) {
                if (snapshot.connectionState == ConnectionState.waiting) {
                  return Center(
                    child: CircularProgressIndicator(
                      color: Colors.teal[700],
                    ),
                  );
                }
                if (snapshot.hasError) {
                  return Center(
                    child: Text(
                      'Error loading plants',
                      style: TextStyle(color: Colors.red[700]),
                    ),
                  );
                }
                final plants = snapshot.data ?? [];
                if (plants.isEmpty) {
                  return _buildEmptyState();
                }
                return ListView.builder(
                  padding: const EdgeInsets.only(bottom: 80),
                  itemCount: plants.length,
                  itemBuilder: (context, index) => PlantCard(
                    plant: plants[index],
                    onWaterPressed: () => _waterPlant(plants[index]),
                    onDeletePressed: () => _deletePlant(plants[index].id),
                    onHealthPressed: () => _showHealthEditor(plants[index]),
                  ),
                );
              },
            ),
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton(
        backgroundColor: Colors.teal[800],
        child: const Icon(Icons.add, color: Colors.white, size: 30),
        onPressed: _navigateToAddPlant,
        elevation: 5,
      ),
    );
  }

  Widget _buildEmptyState() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          const Icon(Icons.eco, size: 100, color: Colors.teal),
          const SizedBox(height: 20),
          Text(
            'No plants yet!',
            style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Colors.teal[700]),
          ),
          const SizedBox(height: 10),
          Text(
            'Tap the + button to add your first plant',
            style: TextStyle(fontSize: 14, color: Colors.teal[600]),
          ),
        ],
      ),
    );
  }

  Future<void> _waterPlant(Plant plant) async {
    if (_isWatering) return;
    setState(() => _isWatering = true);
    try {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Watering ${plant.name}...'),
          duration: const Duration(seconds: 1),
        ),
      );
      await _firestoreService.waterPlant(plant.id);
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('${plant.name} watered successfully! 💧'),
          backgroundColor: Colors.teal[600],
        ),
      );
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Failed to water plant: ${e.toString()}'),
          backgroundColor: Colors.red[600],
        ),
      );
    } finally {
      if (mounted) {
        setState(() => _isWatering = false);
      }
    }
  }

  void _deletePlant(String plantId) async {
    await _firestoreService.deletePlant(plantId);
  }

  void _showHealthEditor(Plant plant) {
    showDialog(
      context: context,
      builder: (context) => HealthEditor(
        initialScore: plant.healthScore,
        onSave: (newScore) => _updateHealth(plant.id, newScore),
      ),
    );
  }

  Future<void> _updateHealth(String plantId, int newScore) async {
    await _firestoreService.updatePlantHealth(plantId, newScore);
  }

  void _navigateToAddPlant() {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => AddPlantScreen(userId: widget.userId),
      ),
    );
  }
}
