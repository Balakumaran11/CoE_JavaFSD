import 'package:flutter/material.dart';

class ProfileScreen extends StatelessWidget {
  const ProfileScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    debugPrint("Building ProfileScreen UI"); // Debug check
    
    return Scaffold(
      appBar: AppBar(
        title: const Text("Profile"),
        backgroundColor: Colors.green,
      ),
      body: const Center(
        child: Text(
          "PROFILE SCREEN VISIBLE", // Debug text
          style: TextStyle(fontSize: 24),
        ),
      ),
    );
  }
}