import 'package:flutter/material.dart';

class AppLocalizations {
  final Locale locale;

  AppLocalizations(this.locale);

  static AppLocalizations? of(BuildContext context) {
    return Localizations.of<AppLocalizations>(context, AppLocalizations);
  }

  static const LocalizationsDelegate<AppLocalizations> delegate = _AppLocalizationsDelegate();

  // Simple hardcoded translations (you can expand this)
  Map<String, String> get translations {
    switch (locale.languageCode) {
      case 'es':
        return _esTranslations;
      case 'fr':
        return _frTranslations;
      default: // English as fallback
        return _enTranslations;
    }
  }

  static final Map<String, String> _enTranslations = {
    'appTitle': 'Plant Care',
    'homeTitle': 'My Plants',
    'addPlant': 'Add Plant',
  };

  static final Map<String, String> _esTranslations = {
    'appTitle': 'Cuidado de Plantas',
    'homeTitle': 'Mis Plantas',
    'addPlant': 'Añadir Planta',
  };

  static final Map<String, String> _frTranslations = {
    'appTitle': 'Soin des Plantes',
    'homeTitle': 'Mes Plantes',
    'addPlant': 'Ajouter une Plante',
  };
}

class _AppLocalizationsDelegate extends LocalizationsDelegate<AppLocalizations> {
  const _AppLocalizationsDelegate();

  @override
  bool isSupported(Locale locale) => ['en', 'es', 'fr'].contains(locale.languageCode);

  @override
  Future<AppLocalizations> load(Locale locale) async {
    return AppLocalizations(locale);
  }

  @override
  bool shouldReload(_AppLocalizationsDelegate old) => false;
}