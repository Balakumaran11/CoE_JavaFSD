import 'package:cloud_firestore/cloud_firestore.dart';

class Plant {
  final String id;
  final String name;
  final int wateringFrequency;
  final DateTime lastWatered;
  final String userId;
  final int healthScore;

  Plant({
    required this.id,
    required this.name,
    required this.wateringFrequency,
    required this.lastWatered,
    required this.userId,
    this.healthScore = 80,
  });

  String get healthStatus {
    if (healthScore >= 80) return "Excellent";
    if (healthScore >= 50) return "Good"; 
    return "Needs Care";
  }

  int get daysSinceWatered => DateTime.now().difference(lastWatered).inDays;
  bool get needsWatering => daysSinceWatered >= wateringFrequency;

  factory Plant.fromFirestore(DocumentSnapshot doc) {
    final data = doc.data() as Map<String, dynamic>;
    return Plant(
      id: doc.id,
      name: data['name'] ?? 'Unnamed Plant',
      wateringFrequency: data['wateringFrequency'] ?? 7,
      lastWatered: (data['lastWatered'] as Timestamp).toDate(),
      userId: data['userId'] ?? '',
      healthScore: data['healthScore'] ?? 80,
    );
  }
}