import 'package:flutter/material.dart';

class AppTextStyles {
  static const TextStyle headline = TextStyle(
    fontSize: 24,
    fontWeight: FontWeight.bold,
    color: Colors.white,
  );
  
  static const TextStyle title = TextStyle(
    fontSize: 18,
    fontWeight: FontWeight.bold,
    color: Colors.black87,
  );
  
  static const TextStyle subtitleWhite = TextStyle(
    fontSize: 16,
    color: Colors.white,
  );
  
  static const TextStyle bodyText = TextStyle(
    fontSize: 14,
    color: Colors.grey,
  );
  
  static const TextStyle captionWhite = TextStyle(
    fontSize: 12,
    color: Colors.white70,
  );
}