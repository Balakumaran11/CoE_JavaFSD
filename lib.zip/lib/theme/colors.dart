import 'package:flutter/material.dart';

class AppColors {
  static const Color primary = Color(0xFF4CAF50);
  static const Color primaryDark = Color(0xFF388E3C);
  static const Color accent = Color(0xFF8BC34A);
  static const Color urgent = Color(0xFFFF7043);
  static const Color background = Color(0xFFF5F5F5);
  static const Color lightGrey = Color(0xFFEEEEEE);
  static const Color lightPrimary = Color(0xFFE8F5E9);
  
  static const Gradient primaryGradient = LinearGradient(
    colors: [Color(0xFF4CAF50), Color(0xFF26A69A)],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );
}