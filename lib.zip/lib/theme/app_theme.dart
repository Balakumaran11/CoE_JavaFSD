import 'package:flutter/material.dart';
import 'colors.dart';
import 'text_styles.dart';

class AppTheme {
  static const Color primary = AppColors.primary;
  static const Color urgent = AppColors.urgent;
  static const Color lightPrimary = AppColors.lightPrimary;
  static const Color lightGrey = AppColors.lightGrey;
  static const Color accent = AppColors.accent;
  static const Color background = AppColors.background;
  
  static const Gradient primaryGradient = AppColors.primaryGradient;
  
  static const TextStyle headline = AppTextStyles.headline;
  static const TextStyle title = AppTextStyles.title;
  static const TextStyle subtitleWhite = AppTextStyles.subtitleWhite;
  static const TextStyle bodyText = AppTextStyles.bodyText;
  static const TextStyle captionWhite = AppTextStyles.captionWhite;
  
  static const List<BoxShadow> shadows = [
    BoxShadow(
      color: Color(0x10000000),
      blurRadius: 10,
      offset: Offset(0, 4),
    ),
  ];
  
  static ThemeData get themeData {
    return ThemeData(
      primaryColor: primary,
      scaffoldBackgroundColor: background,
      fontFamily: 'Poppins',
      appBarTheme: AppBarTheme(
        elevation: 0,
        centerTitle: true,
      ),
    );
  }
}