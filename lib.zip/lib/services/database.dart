import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:plantpal/models/plant.dart';

class DatabaseService {
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  // Add this getter method
  Stream<List<Plant>> get plants {
    return _firestore
        .collection('plants')
        .snapshots()
        .map((snapshot) => snapshot.docs
            .map((doc) => Plant.fromFirestore(doc))
            .toList());
  }

  Future<void> addPlant(Plant plant) async {
    await _firestore.collection('plants').add(plant.toFirestore());
  }

  Future<void> updatePlant(Plant plant) async {
    if (plant.id == null) return;
    await _firestore
        .collection('plants')
        .doc(plant.id)
        .update(plant.toFirestore());
  }
}