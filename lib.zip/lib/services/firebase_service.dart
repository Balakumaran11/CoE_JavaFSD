import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:plantpal/firebase_options.dart';

class FirebaseService {
  static Future<User?> _currentUser;

  // Initialize Firebase
  static Future<void> initialize() async {
    await Firebase.initializeApp(
      options: DefaultFirebaseOptions.currentPlatform,
    );
    _currentUser = _getCurrentUser();
  }

  // Get current user (cached)
  static Future<User?> get currentUser async => await _currentUser;

  // Email/password sign in
  static Future<User?> signInWithEmail(String email, String password) async {
    try {
      final credential = await FirebaseAuth.instance.signInWithEmailAndPassword(
        email: email.trim(),
        password: password,
      );
      _currentUser = Future.value(credential.user);
      return credential.user;
    } on FirebaseAuthException catch (e) {
      throw _handleAuthError(e);
    } catch (e) {
      throw 'An unexpected error occurred';
    }
  }

  // Email/password registration
  static Future<User?> registerWithEmail(String email, String password) async {
    try {
      final credential = await FirebaseAuth.instance.createUserWithEmailAndPassword(
        email: email.trim(),
        password: password,
      );
      _currentUser = Future.value(credential.user);
      return credential.user;
    } on FirebaseAuthException catch (e) {
      throw _handleAuthError(e);
    } catch (e) {
      throw 'An unexpected error occurred';
    }
  }

  // Sign out
  static Future<void> signOut() async {
    try {
      await FirebaseAuth.instance.signOut();
      _currentUser = Future.value(null);
    } catch (e) {
      throw 'Failed to sign out';
    }
  }

  // Password reset
  static Future<void> sendPasswordResetEmail(String email) async {
    try {
      await FirebaseAuth.instance.sendPasswordResetEmail(email: email.trim());
    } on FirebaseAuthException catch (e) {
      throw _handleAuthError(e);
    } catch (e) {
      throw 'Failed to send reset email';
    }
  }

  // Get current user ID
  static Future<String?> getCurrentUserId() async {
    final user = await currentUser;
    return user?.uid;
  }

  // Helper to get current user
  static Future<User?> _getCurrentUser() async {
    return FirebaseAuth.instance.currentUser;
  }

  // Handle Firebase auth errors
  static String _handleAuthError(FirebaseAuthException e) {
    switch (e.code) {
      case 'invalid-email':
        return 'Please enter a valid email address';
      case 'user-disabled':
        return 'This account has been disabled';
      case 'user-not-found':
        return 'No account found for this email';
      case 'wrong-password':
        return 'Incorrect password';
      case 'email-already-in-use':
        return 'This email is already registered';
      case 'operation-not-allowed':
        return 'Email/password accounts are not enabled';
      case 'weak-password':
        return 'Password is too weak (min 6 characters)';
      case 'too-many-requests':
        return 'Too many attempts. Try again later';
      default:
        return e.message ?? 'An authentication error occurred';
    }
  }
}