import 'package:http/http.dart' as http;

class ApiService {
  final String baseUrl;

  ApiService(this.baseUrl);

  Future<http.Response> get(String endpoint) async {
    return await http.get(Uri.parse('$baseUrl/$endpoint'));
  }

  Future<http.Response> post(String endpoint, dynamic data) async {
    return await http.post(
      Uri.parse('$baseUrl/$endpoint'),
      body: data,
    );
  }
}