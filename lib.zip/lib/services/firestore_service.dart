import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:plantpal/models/plant.dart';

class FirestoreService {
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  CollectionReference<Map<String, dynamic>> get _plantsCollection => 
      _firestore.collection('plants');

  Stream<List<Plant>> getPlantsStream(String userId) {
    return _plantsCollection
        .where('userId', isEqualTo: userId)
        .snapshots()
        .map((snapshot) => snapshot.docs
            .map((doc) => Plant.fromFirestore(doc))
            .toList());
  }

  Future<void> addPlant(Plant plant) async {
    await _plantsCollection.add({
      'name': plant.name,
      'wateringFrequency': plant.wateringFrequency,
      'lastWatered': Timestamp.fromDate(plant.lastWatered),
      'userId': plant.userId,
      'healthScore': plant.healthScore,
    });
  }

  Future<void> waterPlant(String plantId) async {
    await _plantsCollection.doc(plantId).update({
      'lastWatered': Timestamp.now(),
    });
  }

  Future<void> updatePlantHealth(String plantId, int healthScore) async {
    await _plantsCollection.doc(plantId).update({
      'healthScore': healthScore,
      'lastHealthCheck': Timestamp.now(),
    });
  }

  Future<void> deletePlant(String plantId) async {
    await _plantsCollection.doc(plantId).delete();
  }
}