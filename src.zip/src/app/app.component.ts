import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, RouterOutlet } from '@angular/router';
import { HeaderComponent } from './header/header.component';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [
    CommonModule,
    RouterModule,
    RouterOutlet, // Explicitly import RouterOutlet
    HeaderComponent
  ],
  template: `
    <app-header></app-header>
    <main [class.dark-mode]="isDarkMode">
      <router-outlet></router-outlet>
    </main>
  `,
  styles: [`
    .dark-mode {
      background-color: #121212;
      color: #ffffff;
    }
    main {
      min-height: 100vh;
      padding: 2rem;
    }
  `]
})
export class AppComponent {
  isDarkMode = false;

  toggleDarkMode() {
    this.isDarkMode = !this.isDarkMode;
    // Optional: Save preference to localStorage
    localStorage.setItem('darkMode', String(this.isDarkMode));
  }

  constructor() {
    // Load dark mode preference on init
    const savedMode = localStorage.getItem('darkMode');
    this.isDarkMode = savedMode === 'true';
    
    // Apply immediately
    if (this.isDarkMode) {
      document.body.classList.add('dark-mode');
    }
  }
}