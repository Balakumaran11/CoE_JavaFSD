import { Component, Input, Output, EventEmitter } from '@angular/core';
import { CommonModule, DatePipe } from '@angular/common';
import { RouterModule } from '@angular/router';
import { Task } from '../services/task.service';
import { PriorityPipe } from '../pipes/priority.pipe';

@Component({
  selector: 'app-task-list',
  standalone: true,
  imports: [CommonModule, RouterModule, PriorityPipe, DatePipe],
  // ... rest of the component remains the same ...
})
export class TaskListComponent {
  // ... implementation ...
}