import { Component, Input, Output, EventEmitter } from '@angular/core';
import { Task } from '../models/task.model';
import { CommonModule } from '@angular/common';
import { PriorityPipe } from '../pipes/priority.pipe';
import { DatePipe } from '@angular/common';

@Component({
  selector: 'app-task-list',
  standalone: true,
  imports: [CommonModule, PriorityPipe, DatePipe],
  templateUrl: './task-list.component.html',
  styleUrls: ['./task-list.component.css']
})
export class TaskListComponent {
  @Input() tasks: Task[] = [];
  @Input() selectedTaskId: string | null = null;
  @Output() taskSelected = new EventEmitter<string>();
  @Output() taskCompleted = new EventEmitter<Task>();

  onSelect(taskId: string): void {
    this.taskSelected.emit(taskId);
  }

  onComplete(task: Task): void {
    this.taskCompleted.emit(task); // Emit the complete task object
  }

  getPriorityClass(priority?: string): string {
    return priority ? `priority-${priority.toLowerCase()}` : '';
  }
}