import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { TaskService } from '../services/task.service';
import { Router } from '@angular/router';
import { Task } from '../models/task.model';

@Component({
  selector: 'app-add-task',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './add-task.component.html',
  styleUrls: ['./add-task.component.css']
})
export class AddTaskComponent {
  newTask: Omit<Task, 'id'> = {
    title: '',
    description: '',
    completed: false,
    priority: 'medium'
  };

  constructor(
    private taskService: TaskService,
    private router: Router
  ) {}

  addTask(): void {
    if (!this.newTask.title.trim()) return;
    
    this.taskService.addTask({
      ...this.newTask,
      id: Date.now() // Temporary ID for local testing
    } as Task).subscribe({
      next: () => this.router.navigate(['/dashboard']),
      error: (err) => console.error('Failed to add task', err)
    });
  }
}