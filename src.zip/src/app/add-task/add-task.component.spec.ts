import { ComponentFixture, TestBed } from '@angular/core/testing';
import { AddTaskComponent } from './add-task.component';
import { RouterTestingModule } from '@angular/router/testing';
import { FormsModule } from '@angular/forms';
import { TaskService } from '../services/task.service';

describe('AddTaskComponent', () => {
  let component: AddTaskComponent;
  let fixture: ComponentFixture<AddTaskComponent>;
  let mockTaskService: jasmine.SpyObj<TaskService>;

  beforeEach(async () => {
    mockTaskService = jasmine.createSpyObj('TaskService', ['addTask']);
    
    await TestBed.configureTestingModule({
      imports: [FormsModule, RouterTestingModule],
      declarations: [AddTaskComponent],
      providers: [
        { provide: TaskService, useValue: mockTaskService }
      ]
    }).compileComponents();

    fixture = TestBed.createComponent(AddTaskComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should require title field', () => {
    const titleInput = fixture.nativeElement.querySelector('#title');
    titleInput.value = '';
    titleInput.dispatchEvent(new Event('input'));
    fixture.detectChanges();
    
    expect(component.task.title).toBe('');
    expect(fixture.nativeElement.querySelector('.error')).toBeTruthy();
    expect(fixture.nativeElement.querySelector('button[type="submit"]').disabled).toBeTrue();
  });

  it('should call taskService.addTask on valid form submission', () => {
    component.task = {
      title: 'Test Task',
      description: 'Test Description',
      dueDate: '2023-12-31',
      priority: 'high',
      completed: false
    };
    
    fixture.detectChanges();
    fixture.nativeElement.querySelector('form').dispatchEvent(new Event('submit'));
    
    expect(mockTaskService.addTask).toHaveBeenCalled();
  });
});