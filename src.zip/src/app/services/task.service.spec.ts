import { TestBed } from '@angular/core/testing';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { TaskService } from './task.service';
import { Task } from '../models/task.model';

describe('TaskService', () => {
  let service: TaskService;
  let httpMock: HttpTestingController;
  
  const mockTasks: Task[] = [
    { id: '1', title: 'Task 1', priority: 'medium', completed: false },
    { id: '2', title: 'Task 2', priority: 'high', completed: true }
  ];

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule],
      providers: [TaskService]
    });

    service = TestBed.inject(TaskService);
    httpMock = TestBed.inject(HttpTestingController);
    localStorage.clear();
  });

  afterEach(() => {
    httpMock.verify();
    localStorage.clear();
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  it('should fetch tasks from API', () => {
    service.getTasks().subscribe(tasks => {
      expect(tasks).toEqual(mockTasks);
    });

    const req = httpMock.expectOne('http://localhost:3000/api/tasks');
    expect(req.request.method).toBe('GET');
    req.flush(mockTasks);
  });

  it('should add a new task', () => {
    const newTask: Omit<Task, 'id'> = {
      title: 'New Task',
      priority: 'low',
      completed: false
    };

    service.addTask(newTask).subscribe(task => {
      expect(task).toEqual({ ...newTask, id: '3' });
    });

    const req = httpMock.expectOne('http://localhost:3000/api/tasks');
    expect(req.request.method).toBe('POST');
    req.flush({ ...newTask, id: '3' });
  });

  it('should update a task', () => {
    const updatedTask: Task = { 
      ...mockTasks[0], 
      title: 'Updated Task' 
    };

    service.updateTask(updatedTask).subscribe(task => {
      expect(task).toEqual(updatedTask);
    });

    const req = httpMock.expectOne(`http://localhost:3000/api/tasks/${updatedTask.id}`);
    expect(req.request.method).toBe('PUT');
    req.flush(updatedTask);
  });

  it('should handle errors when fetching tasks', () => {
    spyOn(console, 'error');
    
    service.getTasks().subscribe({
      next: () => fail('should have failed'),
      error: (error) => {
        expect(error).toContain('Failed to load tasks');
      }
    });

    const req = httpMock.expectOne('http://localhost:3000/api/tasks');
    req.flush('Error', { 
      status: 500, 
      statusText: 'Server Error' 
    });
  });

  it('should get task by ID', () => {
    service.getTasks().subscribe(); // Initial load
    const req1 = httpMock.expectOne('http://localhost:3000/api/tasks');
    req1.flush(mockTasks);

    const task = service.getTaskById('1');
    expect(task).toEqual(mockTasks[0]);
  });

  it('should delete a task', () => {
    const taskId = '1';

    service.deleteTask(taskId).subscribe(response => {
      expect(response).toBeNull();
    });

    const req = httpMock.expectOne(`http://localhost:3000/api/tasks/${taskId}`);
    expect(req.request.method).toBe('DELETE');
    req.flush(null);
  });
});