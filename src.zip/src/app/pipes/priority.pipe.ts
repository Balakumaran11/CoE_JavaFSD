// src/app/pipes/priority.pipe.ts
import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'priority',
  standalone: true
})
export class PriorityPipe implements PipeTransform {
  transform(value?: string): string {
    if (!value) return '';
    const icons: Record<string, string> = {
      high: '▲',
      medium: '►',
      low: '▼'
    };
    return icons[value.toLowerCase()] || value.toUpperCase();
  }
}