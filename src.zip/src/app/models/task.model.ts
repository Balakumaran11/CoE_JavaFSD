export interface Task {
  id: number;
  title: string;
  description?: string;
  completed: boolean;
  priority?: 'low' | 'medium' | 'high';
  categories?: string[];  // Add this line
  dueDate?: Date;
}