import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { HttpClientModule } from '@angular/common/http';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import { AppComponent } from './app.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { AddTaskComponent } from './add-task/add-task.component';
import { LoginComponent } from './login/login.component';
import { RouterModule } from '@angular/router';
import { routes } from './app.routes';
import { AuthGuard } from './services/auth.guard';
import { AuthService } from './services/auth.service';
import { TaskService } from './services/task.service';

@NgModule({
  declarations: [
    AppComponent,
    DashboardComponent,
    AddTaskComponent,
    LoginComponent
  ],
  imports: [
    BrowserModule,
    HttpClientModule,
    FormsModule,
    ReactiveFormsModule,
    RouterModule.forRoot(routes, { 
      enableTracing: true, // Add this for debugging
      useHash: true // Try this if routes still don't work
  ],
  providers: [
    AuthGuard,
    AuthService,
    TaskService
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }