import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router } from '@angular/router';
import { CdkDragDrop, CdkDrag, CdkDropList, moveItemInArray } from '@angular/cdk/drag-drop';
import { Task } from '../models/task.model';
import { TaskService } from '../services/task.service';
import { AuthService } from '../services/auth.service';
import confetti from 'canvas-confetti';

@Component({
  selector: 'app-dashboard',
  standalone: true,
  imports: [CommonModule, CdkDrag, CdkDropList],
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit {
  tasks: Task[] = [];
  completedTasks: number = 0;
  pendingTasks: number = 0;

  constructor(
    private taskService: TaskService,
    private authService: AuthService,
    private router: Router
  ) {}

  ngOnInit(): void {
    this.loadTasks();
  }

  loadTasks(): void {
    this.taskService.getTasks().subscribe({
      next: (tasks: Task[]) => {
        this.tasks = tasks;
        this.updateTaskCounts();
      },
      error: (err: Error) => console.error('Failed to load tasks', err)
    });
  }

  updateTaskCounts(): void {
    this.completedTasks = this.tasks.filter(task => task.completed).length;
    this.pendingTasks = this.tasks.length - this.completedTasks;
  }

  onTaskCompleted(task: Task): void {
    task.completed = !task.completed;
    this.taskService.updateTask(task).subscribe({
      next: () => {
        this.updateTaskCounts();
        if (task.completed) {
          this.triggerConfetti();
        }
      },
      error: (err: Error) => {
        console.error('Failed to update task', err);
        task.completed = !task.completed;
      }
    });
  }

  private triggerConfetti(): void {
    try {
      confetti({
        particleCount: 100,
        spread: 70,
        origin: { y: 0.6 }
      });
    } catch (e) {
      console.warn('Confetti animation failed', e);
    }
  }

  logout(): void {
    this.authService.logout();
    this.router.navigate(['/login']);
  }

  drop(event: CdkDragDrop<Task[]>): void {
    moveItemInArray(this.tasks, event.previousIndex, event.currentIndex);
    // Removed reorderTasks call unless you implement it
  }
}