import { ComponentFixture, TestBed } from '@angular/core/testing';
import { DashboardComponent } from './dashboard.component';
import { TaskService } from '../services/task.service';
import { of, throwError } from 'rxjs';
import { TaskListComponent } from '../task-list/task-list.component';
import { RouterTestingModule } from '@angular/router/testing';

describe('DashboardComponent', () => {
  let component: DashboardComponent;
  let fixture: ComponentFixture<DashboardComponent>;
  let mockTaskService: jasmine.SpyObj<TaskService>;

  const mockTasks = [
    { id: 1, title: 'Task 1', completed: false },
    { id: 2, title: 'Task 2', completed: true }
  ];

  beforeEach(async () => {
    mockTaskService = jasmine.createSpyObj('TaskService', ['getTasks', 'updateTask']);
    
    await TestBed.configureTestingModule({
      imports: [RouterTestingModule],
      declarations: [DashboardComponent, TaskListComponent],
      providers: [
        { provide: TaskService, useValue: mockTaskService }
      ]
    }).compileComponents();

    fixture = TestBed.createComponent(DashboardComponent);
    component = fixture.componentInstance;
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should load tasks on init', () => {
    mockTaskService.getTasks.and.returnValue(of(mockTasks));
    fixture.detectChanges();
    
    expect(component.tasks).toEqual(mockTasks);
    expect(component.loading).toBeFalse();
    expect(component.error).toBeNull();
  });

  it('should handle error when loading tasks', () => {
    mockTaskService.getTasks.and.returnValue(throwError(() => new Error('Failed')));
    fixture.detectChanges();
    
    expect(component.tasks).toEqual([]);
    expect(component.loading).toBeFalse();
    expect(component.error).toBeTruthy();
  });

  it('should update task when completion status changes', () => {
    const updatedTask = { ...mockTasks[0], completed: true };
    mockTaskService.updateTask.and.returnValue(of(updatedTask));
    
    component.onTaskCompleted(updatedTask);
    
    expect(mockTaskService.updateTask).toHaveBeenCalledWith(updatedTask);
  });

  it('should show loading indicator while loading', () => {
    mockTaskService.getTasks.and.returnValue(of(mockTasks));
    component.loading = true;
    fixture.detectChanges();
    
    const loadingElement = fixture.nativeElement.querySelector('.loading-indicator');
    expect(loadingElement).toBeTruthy();
  });

  it('should show error message when loading fails', () => {
    component.error = 'Test error';
    fixture.detectChanges();
    
    const errorElement = fixture.nativeElement.querySelector('.error-message');
    expect(errorElement.textContent).toContain('Test error');
  });
});