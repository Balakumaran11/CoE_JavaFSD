import { ComponentFixture, TestBed } from '@angular/core/testing';
import { PageNotFoundComponent } from './page-not-found.component';
import { RouterTestingModule } from '@angular/router/testing';

describe('PageNotFoundComponent', () => {
  let component: PageNotFoundComponent;
  let fixture: ComponentFixture<PageNotFoundComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [RouterTestingModule],
      declarations: [PageNotFoundComponent]
    }).compileComponents();

    fixture = TestBed.createComponent(PageNotFoundComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should display 404 error code', () => {
    const errorCode = fixture.nativeElement.querySelector('.error-code');
    expect(errorCode.textContent).toContain('404');
  });

  it('should display page not found message', () => {
    const title = fixture.nativeElement.querySelector('.title');
    expect(title.textContent).toContain('Page Not Found');
  });

  it('should have a home button', () => {
    const homeButton = fixture.nativeElement.querySelector('.home-button');
    expect(homeButton).toBeTruthy();
    expect(homeButton.getAttribute('routerLink')).toBe('/');
  });

  it('should display ghost animation', () => {
    const ghost = fixture.nativeElement.querySelector('.ghost');
    expect(ghost).toBeTruthy();
  });
});