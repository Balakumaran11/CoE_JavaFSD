import { ComponentFixture, TestBed } from '@angular/core/testing';
import { HeaderComponent } from './header.component';
import { RouterTestingModule } from '@angular/router/testing';

describe('HeaderComponent', () => {
  let component: HeaderComponent;
  let fixture: ComponentFixture<HeaderComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [RouterTestingModule],
      declarations: [HeaderComponent]
    }).compileComponents();

    fixture = TestBed.createComponent(HeaderComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should toggle menu', () => {
    expect(component.isMenuOpen).toBeFalse();
    component.toggleMenu();
    expect(component.isMenuOpen).toBeTrue();
    component.toggleMenu();
    expect(component.isMenuOpen).toBeFalse();
  });

  it('should check login status', () => {
    spyOn(localStorage, 'getItem').and.returnValue('true');
    expect(component.isLoggedIn).toBeTrue();

    (localStorage.getItem as jasmine.Spy).and.returnValue(null);
    expect(component.isLoggedIn).toBeFalse();
  });

  it('should logout', () => {
    spyOn(localStorage, 'removeItem');
    spyOn(window.location, 'href', 'set');
    
    component.logout();
    
    expect(localStorage.removeItem).toHaveBeenCalledWith('isLoggedIn');
    expect(window.location.href).toBe('/login');
  });

  it('should show menu items correctly', () => {
    // Test for logged in state
    spyOnProperty(component, 'isLoggedIn', 'get').and.returnValue(true);
    fixture.detectChanges();
    
    const logoutButton = fixture.nativeElement.querySelector('.logout-button');
    expect(logoutButton).toBeTruthy();

    // Test for logged out state
    spyOnProperty(component, 'isLoggedIn', 'get').and.returnValue(false);
    fixture.detectChanges();
    
    const loginLink = fixture.nativeElement.querySelector('a[routerLink="/login"]');
    expect(loginLink).toBeTruthy();
  });
});