import { ComponentFixture, TestBed } from '@angular/core/testing';
import { TaskDetailComponent } from './task-detail.component';
import { ActivatedRoute, Router } from '@angular/router';
import { TaskService } from '../services/task.service';
import { of, throwError } from 'rxjs';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { RouterTestingModule } from '@angular/router/testing';

describe('TaskDetailComponent', () => {
  let component: TaskDetailComponent;
  let fixture: ComponentFixture<TaskDetailComponent>;
  let taskService: TaskService;
  let router: Router;

  const mockTask: Task = {
    id: 1,
    title: 'Test Task',
    description: 'Test Description',
    priority: 'medium',
    completed: false,
    dueDate: '2023-12-31',
    createdAt: new Date()
  };

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [HttpClientTestingModule, RouterTestingModule],
      declarations: [TaskDetailComponent],
      providers: [
        {
          provide: ActivatedRoute,
          useValue: {
            paramMap: of(new Map([['id', '1']]))
          }
        }
      ]
    }).compileComponents();

    fixture = TestBed.createComponent(TaskDetailComponent);
    component = fixture.componentInstance;
    taskService = TestBed.inject(TaskService);
    router = TestBed.inject(Router);
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should load task on init', () => {
    spyOn(taskService, 'getTaskById').and.returnValue(of(mockTask));
    fixture.detectChanges();
    
    expect(component.task).toEqual(mockTask);
    expect(component.isLoading).toBeFalse();
  });

  it('should handle task not found', () => {
    spyOn(taskService, 'getTaskById').and.returnValue(of(undefined));
    fixture.detectChanges();
    
    expect(component.task).toBeNull();
    expect(component.error).toBe('Task not found');
  });

  it('should handle loading error', () => {
    spyOn(taskService, 'getTaskById').and.returnValue(throwError(() => new Error('Error')));
    fixture.detectChanges();
    
    expect(component.error).toBe('Failed to load task');
    expect(component.isLoading).toBeFalse();
  });

  it('should toggle edit mode', () => {
    component.isEditing = false;
    component.toggleEdit();
    expect(component.isEditing).toBeTrue();
    component.toggleEdit();
    expect(component.isEditing).toBeFalse();
  });

  it('should save task', () => {
    component.task = mockTask;
    spyOn(taskService, 'updateTask').and.returnValue(of(mockTask));
    
    component.saveTask();
    
    expect(taskService.updateTask).toHaveBeenCalledWith(mockTask);
  });

  it('should handle save error', () => {
    component.task = mockTask;
    spyOn(taskService, 'updateTask').and.returnValue(throwError(() => new Error('Error')));
    spyOn(console, 'error');
    
    component.saveTask();
    
    expect(component.error).toBe('Failed to update task');
  });

  it('should delete task', () => {
    component.task = mockTask;
    spyOn(window, 'confirm').and.returnValue(true);
    spyOn(taskService, 'deleteTask').and.returnValue(of(undefined));
    spyOn(router, 'navigate');
    
    component.deleteTask();
    
    expect(taskService.deleteTask).toHaveBeenCalledWith(1);
    expect(router.navigate).toHaveBeenCalledWith(['/dashboard']);
  });

  it('should toggle completion status', () => {
    component.task = mockTask;
    spyOn(taskService, 'updateTask').and.returnValue(of(mockTask));
    
    component.toggleCompletion();
    expect(component.task.completed).toBeTrue();
    
    component.toggleCompletion();
    expect(component.task.completed).toBeFalse();
  });
});